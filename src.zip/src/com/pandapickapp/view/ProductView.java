package com.pandapickapp.view;

import com.pandapickapp.commons.ProductDTO;
import com.pandapickapp.controller.ProductController;

import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.layout.HBox;

public class ProductView extends HBox {
    
    private final Label nameLabel;
    private final Spinner<Integer> quantitySpinner;
    private final ProductController controller;

    public ProductView(ProductDTO product) {
        this.controller = new ProductController();
        
        this.nameLabel = new Label(product.getName());
        this.quantitySpinner = new Spinner<>();
        
        // Configurar el componente de cantidad (permite 0, incrementos de 1 en 1)
        controller.setupQuantitySpinner(quantitySpinner, product);
        
        // Estilo y diseño básico de la vista en fila
        this.getChildren().addAll(nameLabel, quantitySpinner);
        this.setSpacing(10);
    }
}