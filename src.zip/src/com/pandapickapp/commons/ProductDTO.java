package com.pandapickapp.commons;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ProductDTO {
    private final int id;
    private final StringProperty name;
    private final IntegerProperty quantity;

    public ProductDTO(int id, String name, int initialQuantity) {
        this.id = id;
        this.name = new SimpleStringProperty(name);
        this.quantity = new SimpleIntegerProperty(initialQuantity);
    }

    public int getId() { return id; }

    public String getName() { return name.get(); }
    public StringProperty nameProperty() { return name; }

    public int getQuantity() { return quantity.get(); }
    public void setQuantity(int quantity) { this.quantity.set(quantity); }
    public IntegerProperty quantityProperty() { return quantity; }
}