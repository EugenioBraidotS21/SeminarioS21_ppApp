package com.pandapickapp.controller;

import com.pandapickapp.commons.ProductDTO;

import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;

public class ProductController {

    /**
     * Configura un Spinner de JavaFX para que permita el valor 0, 
     * un valor máximo arbitrario (ej. 100), comience en la cantidad actual 
     * y se incremente de 1 en 1, sincronizándose con el DTO.
     */
    public void setupQuantitySpinner(Spinner<Integer> spinner, ProductDTO product) {
        SpinnerValueFactory<Integer> valueFactory = 
            new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1000, product.getQuantity(), 1);
        
        spinner.setValueFactory(valueFactory);
        spinner.setEditable(true);

        // Sincronizar cambios del Spinner hacia el DTO
        spinner.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                product.setQuantity(newValue);
            }
        });

        // Sincronizar cambios del DTO hacia el Spinner (bidireccional)
        product.quantityProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && newValue.intValue() != spinner.getValue().intValue()) {
                spinner.getValueFactory().setValue(newValue.intValue());
            }
        });
    }
}