package com.pandapickapp.controller;

import java.util.ArrayList;
import java.util.List;

import com.pandapickapp.commons.RubrosDTO;
import com.pandapickapp.model.AliasModel;
import com.pandapickapp.model.RubrosModel;
import com.pandapickapp.view.AliasView;
import com.pandapickapp.view.RubrosView;

import javafx.scene.Scene;
import javafx.stage.Stage;

public class RubrosController {
    private RubrosModel model;
    private RubrosView view;
    private Stage stage;

    public RubrosController(RubrosModel model, RubrosView view, Stage stage) {
        this.model = model;
        this.view = view;
        this.stage = stage;
        inicializar();
    }

    private void inicializar() {
    	// Cargan los Rubros desde la base de datos.
        if (model != null && view != null) {
            view.cargarRubros(model.getRubrosDisponibles());
        }

        if (view != null && view.getBtnVerProductos() != null) {
            view.getBtnVerProductos().setOnAction(e -> onVerProductos());
        }
        
       if (view != null && view.getBtnAtrasProducto() != null) {
            view.getBtnAtrasProducto().setOnAction(e -> onAtras());
        }
    }

    private void onVerProductos() {
        // Lógica para procesar los rubros seleccionados
        System.out.println("Botón Ver productos presionado");
    }
    
    private void onAtras() {
        System.out.println("Cancelando ingreso de Rubros y regresando a Alias...");

        Stage currentStage = this.stage;

        dispose();

        AliasModel aliasModel = new AliasModel();
        AliasView aliasView = new AliasView();
        new AliasController(aliasModel, aliasView, currentStage);

        Scene aliasScene = new Scene(aliasView.getRoot(), 380, 520);
        currentStage.setTitle("PandaPickApp - Alias");
        currentStage.setScene(aliasScene);
    }

    public void dispose() {

    	if (view!=null) {
    		view.limpiarVista();
    	}
    	
        if (model != null) {
        	model.setRubrosDisponibles(null);
        }

        model = null;
        view = null;
        stage = null;
    }
    

}