package com.pandapickapp.util;
	
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class IniciaBase {
    public static void inicializarBaseDeDatos(String urlDB) {
        String sql = """
            -- 1. Crear la tabla de Rubros
			CREATE TABLE IF NOT EXISTS rubros (
			    id INTEGER PRIMARY KEY AUTOINCREMENT,
			    nombre TEXT NOT NULL UNIQUE
			);

			-- 2. Crear la tabla de Productos (asociada a un rubro mediante rubro_id)
			CREATE TABLE IF NOT EXISTS productos (
			    id INTEGER PRIMARY KEY AUTOINCREMENT,
			    nombre TEXT NOT NULL,
			    cantidad INTEGER NOT NULL DEFAULT 0,
			    rubro_id INTEGER NOT NULL,
			    FOREIGN KEY (rubro_id) REFERENCES rubros(id) ON DELETE CASCADE
			);

			-- 3. Insertar Rubros iniciales
			INSERT OR IGNORE INTO rubros (id, nombre) VALUES (1, 'Almacén y Kiosco');
			INSERT OR IGNORE INTO rubros (id, nombre) VALUES (2, 'Bebidas');
			INSERT OR IGNORE INTO rubros (id, nombre) VALUES (3, 'Limpieza y Perfumería');
			INSERT OR IGNORE INTO rubros (id, nombre) VALUES (4, 'Lácteos y Fiambrería');

			-- 4. Insertar 10 Productos para el Rubro 1: Almacén y Kiosco
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Yerba Mate 1kg', 0, 1);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Fideos Tallarín 500g', 0, 1);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Arroz Largo Fino 1kg', 0, 1);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Aceite de Girasol 900ml', 0, 1);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Harina de Trigo 000 1kg', 0, 1);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Azúcar Común 1kg', 0, 1);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Puré de Tomate 520g', 0, 1);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Galletitas de Agua 3パック', 0, 1);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Café Instantáneo 170g', 0, 1);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Atún en Aceite 170g', 0, 1);
			
			-- 5. Insertar 10 Productos para el Rubro 2: Bebidas
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Agua Mineral sin Gas 1.5L', 0, 2);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Gaseosa Cola 2.25L', 0, 2);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Gaseosa Lima-Limón 2.25L', 0, 2);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Jugo Naranja 1L', 0, 2);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Cerveza Rubia 1L', 0, 2);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Vino Malbec 750ml', 0, 2);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Agua Saborizada Pomelo 1.5L', 0, 2);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Bebida Energética 473ml', 0, 2);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Sidra 720ml', 0, 2);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Soda En Sifón 1.5L', 0, 2);

			-- 6. Insertar 10 Productos para el Rubro 3: Limpieza y Perfumería
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Lavandina Tradicional 1L', 0, 3);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Detergente Líquido 500ml', 0, 3);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Jabón en Polvo 800g', 0, 3);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Suavizante para Ropa 900ml', 0, 3);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Papel Higiénico 4 Unidades', 0, 3);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Rollo de Cocina 3 Unidades', 0, 3);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Desinfectante de Pisos 1L', 0, 3);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Esponja Multiuso Doble Soca', 0, 3);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Jabón de Tocador 3 Unidades', 0, 3);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Alcohol en Gel 250ml', 0, 3);
			
			-- 7. Insertar 10 Productos para el Rubro 4: Lácteos y Fiambrería
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Leche Entera Sachet 1L', 0, 4);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Queso Tybo feteado 100g', 0, 4);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Jamón Cocido feteado 100g', 0, 4);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Manteca 200g', 0, 4);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Yogur Firme de Frutilla 190g', 0, 4);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Queso Crema 300g', 0, 4);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Dulce de Leche Clásico 400g', 0, 4);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Crema de Leche 200ml', 0, 4);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Salame Milán en Rodajas 100g', 0, 4);
			INSERT OR IGNORE INTO productos (nombre, cantidad, rubro_id) VALUES ('Queso Untable Light 200g', 0, 4);
			        """;

	        try (Connection conn = DriverManager.getConnection(urlDB);
	             Statement stmt = conn.createStatement()) {
	            stmt.executeUpdate(sql);
	            System.out.println("Tablas 'rubros' y 'productos' creadas o verificadas exitosamente.");
	        } catch (Exception e) {
	            System.err.println("Error al inicializar la base de datos: " + e.getMessage());
	        }
    }
}